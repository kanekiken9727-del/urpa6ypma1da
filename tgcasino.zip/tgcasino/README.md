# TG Casino (virtual chips) — aiogram 3 + PostgreSQL + Mini App

A Telegram game bot with casino-style mini-games played with **virtual chips only**.
There is **no cash-out, no real-money deposits, no crypto, no stars-for-money**.
Chips have no monetary value; the app is entertainment / score-based.

## Features
- Games: Dice guess (1-6), Coin flip, Red/Black, Slots, Crash
- **Provably fair** RNG (server seed hash published in advance, client seed, nonce)
- Balanced payouts with a small, transparent house edge
- Referral system (rewards paid in virtual chips)
- Leaderboard
- Telegram Mini App (WebApp) scaffold

## Quick start
1. `python -m venv .venv && source .venv/bin/activate`
2. `pip install -r requirements.txt`
3. Create a PostgreSQL database and set `DATABASE_URL` in `.env`
4. Copy `.env.example` to `.env`, put your bot token from @BotFather
5. `python -m db.init_db`   # creates tables
6. `python bot.py`

## Project layout
```
tgcasino/
  bot.py                 # entrypoint (polling)
  config.py              # settings from .env
  db/
    database.py          # async engine/session
    models.py            # ORM models
    init_db.py           # create tables
  core/
    provably_fair.py     # provably-fair RNG
    economy.py           # balance ops (atomic)
    games.py             # pure game logic + payouts
  handlers/
    common.py            # /start, menu, balance, referral link
    games.py             # game callbacks
    leaderboard.py       # top players
  keyboards/menus.py     # inline keyboards
  webapp/                # Mini App (static)
```

## Responsible design notes
- Odds are **fair and verifiable** (provably fair). House edge is small and disclosed.
- No real-money integration. If you ever want real stakes, that requires a proper
  gambling licence, KYC/AML and legal counsel — out of scope here by design.
