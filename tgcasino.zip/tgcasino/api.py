"""Mini App HTTP API (aiohttp).

Serves the static Mini App and JSON endpoints. All game outcomes are computed
SERVER-SIDE with the provably-fair engine; the client is never trusted.
Every request that acts on a user must include Telegram WebApp `initData`,
which is validated via HMAC (see validate_init_data) to authenticate the user.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import time
from urllib.parse import parse_qsl

from aiohttp import web

from config import settings
from core import economy, games, provably_fair as pf
from db.database import SessionLocal


def validate_init_data(init_data: str, max_age: int = 86400) -> dict | None:
    """Validate Telegram WebApp initData. Returns parsed fields or None if invalid.

    Algorithm (per Telegram docs):
      secret_key = HMAC_SHA256(key="WebAppData", msg=bot_token)
      check_hash = HMAC_SHA256(key=secret_key, msg=data_check_string)
    """
    try:
        pairs = dict(parse_qsl(init_data, strict_parsing=True))
    except ValueError:
        return None
    received_hash = pairs.pop("hash", None)
    if not received_hash:
        return None
    data_check_string = "\n".join(f"{k}={v}" for k, v in sorted(pairs.items()))
    secret_key = hmac.new(b"WebAppData", settings.bot_token.encode(), hashlib.sha256).digest()
    calc_hash = hmac.new(secret_key, data_check_string.encode(), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(calc_hash, received_hash):
        return None
    # freshness check
    auth_date = int(pairs.get("auth_date", "0"))
    if max_age and auth_date and time.time() - auth_date > max_age:
        return None
    if "user" in pairs:
        pairs["user"] = json.loads(pairs["user"])
    return pairs


async def _auth(request: web.Request) -> dict:
    body = await request.json()
    parsed = validate_init_data(body.get("initData", ""))
    if not parsed or "user" not in parsed:
        raise web.HTTPUnauthorized(text="invalid initData")
    return {"body": body, "tg_user": parsed["user"]}


async def api_state(request: web.Request) -> web.Response:
    ctx = await _auth(request)
    u = ctx["tg_user"]
    async with SessionLocal() as session:
        user = await economy.get_or_create_user(session, int(u["id"]), u.get("username"))
        h = pf.server_seed_hash(user.server_seed)
    return web.json_response({
        "balance": user.balance, "nonce": user.nonce,
        "client_seed": user.client_seed, "server_seed_hash": h,
    })


async def api_play(request: web.Request) -> web.Response:
    ctx = await _auth(request)
    u = ctx["tg_user"]
    body = ctx["body"]
    game = body.get("game")
    try:
        amount = int(body.get("bet", 0))
    except (TypeError, ValueError):
        raise web.HTTPBadRequest(text="bad bet")
    if amount <= 0:
        raise web.HTTPBadRequest(text="bet must be > 0")

    async with SessionLocal() as session:
        user = await economy.get_or_create_user(session, int(u["id"]), u.get("username"))
        if user.balance < amount:
            raise web.HTTPBadRequest(text="insufficient balance")
        ss, cs, nonce = user.server_seed, user.client_seed, user.nonce
        if game == "dice":
            result = games.dice_guess(amount, int(body.get("guess", 0)), ss, cs, nonce)
        elif game == "coin":
            result = games.coin_flip(amount, body.get("choice", ""), ss, cs, nonce)
        elif game == "rb":
            result = games.red_black(amount, body.get("choice", ""), ss, cs, nonce)
        elif game == "slots":
            result = games.slots(amount, ss, cs, nonce)
        elif game == "crash":
            crash = games.crash_point(ss, cs, nonce)
            result = games.crash_settle(amount, float(body.get("cashout", 2.0)), crash)
        else:
            raise web.HTTPBadRequest(text="unknown game")
        try:
            user = await economy.settle_bet(session, user, game, amount, result)
        except ValueError:
            raise web.HTTPBadRequest(text="insufficient balance")

    return web.json_response({
        "win": result.win, "payout": result.payout,
        "multiplier": result.multiplier, "result": result.result,
        "balance": user.balance, "nonce_used": nonce,
    })


async def api_verify(request: web.Request) -> web.Response:
    """Public verification: recompute a round from a revealed server seed."""
    body = await request.json()
    server_seed = body.get("server_seed", "")
    client_seed = body.get("client_seed", "")
    nonce = int(body.get("nonce", 0))
    expected_hash = body.get("server_seed_hash", "")
    return web.json_response(pf.verify_round(server_seed, client_seed, nonce, expected_hash))


async def index(request: web.Request) -> web.FileResponse:
    # serve the Mini App entry so hitting "/" or "/webapp/" never returns 403
    return web.FileResponse("webapp/index.html")


def build_app() -> web.Application:
    app = web.Application()
    app.router.add_post("/api/state", api_state)
    app.router.add_post("/api/play", api_play)
    app.router.add_post("/api/verify", api_verify)
    # explicit entry points (a bare directory would otherwise return 403)
    app.router.add_get("/", index)
    app.router.add_get("/webapp/", index)
    # static assets: css/js/html reachable at /webapp/<file>, so relative
    # links inside index.html (style.css, app.js) keep working
    app.router.add_static("/webapp/", path="webapp", show_index=False)
    return app


if __name__ == "__main__":
    web.run_app(build_app(), host=settings.api_host, port=settings.api_port)
