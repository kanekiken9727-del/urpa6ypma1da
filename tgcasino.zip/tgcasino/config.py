from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8")

    bot_token: str
    database_url: str
    webapp_url: str = "https://example.com/webapp/"
    start_balance: int = 1000
    referral_percent: int = 10
    # comma-separated Telegram user ids allowed to credit virtual chips
    admin_ids: str = ""
    # host/port for the Mini App API server
    api_host: str = "0.0.0.0"
    api_port: int = 8080

    @property
    def admin_id_set(self) -> set[int]:
        return {int(x) for x in self.admin_ids.split(",") if x.strip().isdigit()}


settings = Settings()
