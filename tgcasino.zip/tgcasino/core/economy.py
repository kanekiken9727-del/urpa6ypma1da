"""Atomic balance operations, bet settlement, seed rotation, admin credit."""
from __future__ import annotations

from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession

from config import settings
from core import provably_fair as pf
from core.games import GameResult
from db.models import Bet, RevealedSeed, User


async def get_or_create_user(session: AsyncSession, user_id: int, username: str | None,
                             referred_by: int | None = None) -> User:
    user = await session.get(User, user_id)
    if user:
        if username and user.username != username:
            user.username = username
            await session.commit()
        return user
    user = User(
        id=user_id,
        username=username,
        balance=settings.start_balance,
        server_seed=pf.new_server_seed(),
        client_seed=pf.new_client_seed(),
        nonce=0,
        referred_by=referred_by if referred_by and referred_by != user_id else None,
    )
    session.add(user)
    await session.commit()
    return user


async def settle_bet(session: AsyncSession, user: User, game: str, amount: int,
                     result: GameResult) -> User:
    """Apply a game result atomically. Stores the full provably-fair proof."""
    proof_hash = pf.server_seed_hash(user.server_seed)
    used_nonce = user.nonce

    stmt = (
        update(User)
        .where(User.id == user.id, User.balance >= amount)
        .values(balance=User.balance + result.payout, nonce=User.nonce + 1)
        .returning(User.balance)
    )
    res = await session.execute(stmt)
    row = res.first()
    if row is None:
        await session.rollback()
        raise ValueError("insufficient_balance")

    session.add(Bet(
        user_id=user.id, game=game, amount=amount, payout=result.payout,
        multiplier=f"{result.multiplier:.4f}",
        server_seed_hash=proof_hash, client_seed=user.client_seed,
        nonce=used_nonce, result=result.result,
    ))
    await session.commit()
    await session.refresh(user)
    return user


async def set_client_seed(session: AsyncSession, user: User, client_seed: str) -> User:
    """Let the player choose their own client seed (rotates server seed too, for safety)."""
    client_seed = (client_seed or "").strip()[:32] or pf.new_client_seed()
    # archive current server seed before changing state
    await _archive_current_seed(session, user)
    user.client_seed = client_seed
    user.server_seed = pf.new_server_seed()
    user.nonce = 0
    await session.commit()
    await session.refresh(user)
    return user


async def rotate_server_seed(session: AsyncSession, user: User) -> RevealedSeed:
    """Rotate the server seed and REVEAL the old one so past rounds can be verified."""
    revealed = await _archive_current_seed(session, user)
    user.server_seed = pf.new_server_seed()
    user.nonce = 0
    await session.commit()
    await session.refresh(user)
    return revealed


async def _archive_current_seed(session: AsyncSession, user: User) -> RevealedSeed:
    revealed = RevealedSeed(
        user_id=user.id,
        server_seed=user.server_seed,
        server_seed_hash=pf.server_seed_hash(user.server_seed),
        client_seed=user.client_seed,
        max_nonce=user.nonce,
    )
    session.add(revealed)
    await session.flush()
    return revealed


async def find_revealed_seed(session: AsyncSession, server_seed_hash: str) -> RevealedSeed | None:
    res = await session.execute(
        select(RevealedSeed).where(RevealedSeed.server_seed_hash == server_seed_hash))
    return res.scalars().first()


async def top_up(session: AsyncSession, user: User, amount: int) -> User:
    """Virtual top-up of chips (NOT real money). Pays referral bonus if applicable."""
    user.balance += amount
    if user.referred_by:
        bonus = amount * settings.referral_percent // 100
        if bonus > 0:
            await session.execute(
                update(User).where(User.id == user.referred_by)
                .values(balance=User.balance + bonus))
    await session.commit()
    await session.refresh(user)
    return user


async def admin_credit(session: AsyncSession, target_user_id: int, amount: int) -> int:
    """Admin grants virtual chips. No real-money involvement whatsoever."""
    res = await session.execute(
        update(User).where(User.id == target_user_id)
        .values(balance=User.balance + amount).returning(User.balance))
    row = res.first()
    await session.commit()
    if row is None:
        raise ValueError("user_not_found")
    return row[0]


async def leaderboard(session: AsyncSession, limit: int = 10) -> list[User]:
    res = await session.execute(select(User).order_by(User.balance.desc()).limit(limit))
    return list(res.scalars().all())
