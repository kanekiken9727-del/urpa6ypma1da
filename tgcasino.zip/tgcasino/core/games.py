"""Pure game logic.

Every function is deterministic given the provably-fair inputs.
Payout multipliers include a small house edge (~2-5%), so games are fair
and verifiable but the house keeps a slight, disclosed long-term advantage.
No game lets a player be infinitely +EV.
"""
from __future__ import annotations

from dataclasses import dataclass

from core import provably_fair as pf

# House edge is applied by paying slightly less than the "fair" multiplier.
# Fair multiplier for a p-probability win is 1/p. We pay MULT = (1/p) * (1 - EDGE).
HOUSE_EDGE = 0.03  # 3%


@dataclass
class GameResult:
    win: bool
    payout: int          # net result: +winnings or -amount
    multiplier: float
    result: str          # human/verifiable outcome string


def _mult(prob: float) -> float:
    return (1.0 / prob) * (1.0 - HOUSE_EDGE)


def dice_guess(bet: int, guess: int, server_seed: str, client_seed: str, nonce: int) -> GameResult:
    roll = pf.randint(server_seed, client_seed, nonce, 1, 6)
    if roll == guess:
        mult = _mult(1 / 6)
        return GameResult(True, round(bet * mult) - bet, mult, f"roll={roll}")
    return GameResult(False, -bet, 0.0, f"roll={roll}")


def coin_flip(bet: int, choice: str, server_seed: str, client_seed: str, nonce: int) -> GameResult:
    # choice in {"heads","tails"}
    f = pf.floats(server_seed, client_seed, nonce, 1)[0]
    outcome = "heads" if f < 0.5 else "tails"
    if outcome == choice:
        mult = _mult(0.5)
        return GameResult(True, round(bet * mult) - bet, mult, outcome)
    return GameResult(False, -bet, 0.0, outcome)


def red_black(bet: int, choice: str, server_seed: str, client_seed: str, nonce: int) -> GameResult:
    # choice in {"red","black"}; small "green" slot gives the house its edge (like roulette 0)
    n = pf.randint(server_seed, client_seed, nonce, 0, 36)
    if n == 0:
        color = "green"
    elif n % 2 == 1:
        color = "red"
    else:
        color = "black"
    if color == choice:
        # 18/37 chance -> pay near 2x
        mult = _mult(18 / 37)
        return GameResult(True, round(bet * mult) - bet, mult, f"{n}-{color}")
    return GameResult(False, -bet, 0.0, f"{n}-{color}")


SLOT_SYMBOLS = ["🍒", "🍋", "🔔", "⭐", "7️⃣"]


def slots(bet: int, server_seed: str, client_seed: str, nonce: int) -> GameResult:
    reels = [pf.randint(server_seed, client_seed, nonce * 10 + i, 0, len(SLOT_SYMBOLS) - 1) for i in range(3)]
    symbols = [SLOT_SYMBOLS[r] for r in reels]
    line = "".join(symbols)
    if reels[0] == reels[1] == reels[2]:
        # jackpot depends on symbol rarity index
        mult = [5, 8, 12, 20, 50][reels[0]] * (1 - HOUSE_EDGE)
        return GameResult(True, round(bet * mult) - bet, mult, line)
    if reels[0] == reels[1] or reels[1] == reels[2]:
        mult = 1.5 * (1 - HOUSE_EDGE)
        return GameResult(True, round(bet * mult) - bet, mult, line)
    return GameResult(False, -bet, 0.0, line)


def crash_point(server_seed: str, client_seed: str, nonce: int) -> float:
    """Provably-fair crash multiplier with house edge.

    Classic formula: with probability EDGE the crash is instant (1.00x),
    otherwise multiplier = 1 / (1 - u) capped. This yields fair long-term edge.
    """
    f = pf.floats(server_seed, client_seed, nonce, 1)[0]
    if f < HOUSE_EDGE:
        return 1.00
    m = 1.0 / (1.0 - f)
    return round(min(m, 100.0), 2)


def crash_settle(bet: int, cashout: float, crash: float) -> GameResult:
    """Player set an auto-cashout multiplier; win if crash >= cashout."""
    if crash >= cashout:
        return GameResult(True, round(bet * cashout) - bet, cashout, f"crash={crash}")
    return GameResult(False, -bet, 0.0, f"crash={crash}")
