"""Provably-fair RNG.

Model:
- server_seed: secret, generated per user. Its SHA-256 hash is shown BEFORE bets.
- client_seed: chosen/known by the player.
- nonce: increments each bet.

For each round we compute HMAC_SHA256(server_seed, f"{client_seed}:{nonce}").
The hex digest is turned into floats in [0,1). Because the server_seed hash is
published in advance and revealed later, the player can verify no cheating happened.
"""
from __future__ import annotations

import hashlib
import hmac
import secrets


def new_server_seed() -> str:
    return secrets.token_hex(32)


def new_client_seed() -> str:
    return secrets.token_hex(8)


def server_seed_hash(server_seed: str) -> str:
    return hashlib.sha256(server_seed.encode()).hexdigest()


def _digest(server_seed: str, client_seed: str, nonce: int) -> str:
    msg = f"{client_seed}:{nonce}".encode()
    return hmac.new(server_seed.encode(), msg, hashlib.sha256).hexdigest()


def floats(server_seed: str, client_seed: str, nonce: int, count: int = 1) -> list[float]:
    """Return `count` deterministic floats in [0,1) from the round digest."""
    digest = _digest(server_seed, client_seed, nonce)
    out: list[float] = []
    # each float uses 8 hex chars (32 bits)
    for i in range(count):
        chunk = digest[i * 8:(i + 1) * 8]
        if len(chunk) < 8:
            # extend deterministically if we need more entropy
            chunk = _digest(server_seed, client_seed, nonce + 1000 + i)[:8]
        out.append(int(chunk, 16) / 0x100000000)
    return out


def randint(server_seed: str, client_seed: str, nonce: int, lo: int, hi: int) -> int:
    """Uniform integer in [lo, hi] inclusive."""
    f = floats(server_seed, client_seed, nonce, 1)[0]
    return lo + int(f * (hi - lo + 1))


def verify_round(server_seed: str, client_seed: str, nonce: int,
                 expected_hash: str) -> dict:
    """Recompute a round from a REVEALED server seed and confirm the hash.

    Returns a dict with the digest and derived float, plus whether the
    published hash matches the revealed seed.
    """
    ok_hash = server_seed_hash(server_seed) == expected_hash
    digest = _digest(server_seed, client_seed, nonce)
    f = floats(server_seed, client_seed, nonce, 1)[0]
    return {
        "hash_matches": ok_hash,
        "digest": digest,
        "float": f,
        "dice_1_6": 1 + int(f * 6),
        "coin": "heads" if f < 0.5 else "tails",
    }
