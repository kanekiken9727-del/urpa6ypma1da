from datetime import datetime

from sqlalchemy import (BigInteger, Boolean, DateTime, ForeignKey, Integer,
                        String, func)
from sqlalchemy.orm import (DeclarativeBase, Mapped, mapped_column,
                            relationship)


class Base(DeclarativeBase):
    pass


class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)  # telegram user id
    username: Mapped[str | None] = mapped_column(String(64), nullable=True)
    balance: Mapped[int] = mapped_column(BigInteger, default=0)
    # provably-fair state (active seed)
    server_seed: Mapped[str] = mapped_column(String(64))
    client_seed: Mapped[str] = mapped_column(String(64))
    nonce: Mapped[int] = mapped_column(Integer, default=0)
    # referrals
    referred_by: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    bets: Mapped[list["Bet"]] = relationship(back_populates="user")


class Bet(Base):
    __tablename__ = "bets"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("users.id"))
    game: Mapped[str] = mapped_column(String(32))
    amount: Mapped[int] = mapped_column(BigInteger)
    payout: Mapped[int] = mapped_column(BigInteger)  # net result (+win / -loss)
    multiplier: Mapped[str] = mapped_column(String(16), default="0")
    # full provably-fair proof for this round
    server_seed_hash: Mapped[str] = mapped_column(String(64))
    client_seed: Mapped[str] = mapped_column(String(64))
    nonce: Mapped[int] = mapped_column(Integer)
    result: Mapped[str] = mapped_column(String(64))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    user: Mapped["User"] = relationship(back_populates="bets")


class RevealedSeed(Base):
    """Archive of rotated (now revealed) server seeds, so any past bet can be verified."""
    __tablename__ = "revealed_seeds"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("users.id"))
    server_seed: Mapped[str] = mapped_column(String(64))          # revealed value
    server_seed_hash: Mapped[str] = mapped_column(String(64))     # was published in advance
    client_seed: Mapped[str] = mapped_column(String(64))
    max_nonce: Mapped[int] = mapped_column(Integer)               # rounds played on this seed
    revealed_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
