from aiogram import Router
from aiogram.filters import Command, CommandObject
from aiogram.types import Message

from config import settings
from core import economy
from db.database import SessionLocal

router = Router()


@router.message(Command("credit"))
async def credit(message: Message, command: CommandObject) -> None:
    """Admin-only: grant VIRTUAL chips. Usage: /credit <user_id> <amount>. No real money."""
    if message.from_user.id not in settings.admin_id_set:
        await message.answer("⛔ Команда только для администраторов.")
        return
    args = (command.args or "").split()
    if len(args) != 2 or not args[0].isdigit() or not args[1].lstrip("-").isdigit():
        await message.answer("Использование: <code>/credit &lt;user_id&gt; &lt;amount&gt;</code>")
        return
    target, amount = int(args[0]), int(args[1])
    async with SessionLocal() as session:
        try:
            new_balance = await economy.admin_credit(session, target, amount)
        except ValueError:
            await message.answer("Пользователь не найден (должен хотя бы раз запустить /start).")
            return
    await message.answer(f"✅ Начислено {amount} виртуальных фишек. Новый баланс {target}: {new_balance}.")
