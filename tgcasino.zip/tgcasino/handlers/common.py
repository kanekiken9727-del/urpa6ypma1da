from aiogram import F, Router
from aiogram.filters import CommandObject, CommandStart
from aiogram.types import CallbackQuery, Message

from config import settings
from core import economy, provably_fair as pf
from db.database import SessionLocal

router = Router()


def _parse_ref(args: str | None) -> int | None:
    if args and args.startswith("ref_"):
        try:
            return int(args[4:])
        except ValueError:
            return None
    return None


@router.message(CommandStart())
async def start(message: Message, command: CommandObject) -> None:
    ref = _parse_ref(command.args)
    async with SessionLocal() as session:
        user = await economy.get_or_create_user(
            session, message.from_user.id, message.from_user.username, referred_by=ref)
    from keyboards.menus import main_menu
    await message.answer(
        f"🎰 Добро пожаловать в TG Casino (фишки — только для развлечения, без вывода в деньги)!\n"
        f"Ваш баланс: <b>{user.balance}</b> фишек.\n\n"
        f"Выберите игру:",
        reply_markup=main_menu(),
    )


@router.callback_query(F.data == "menu")
async def back_to_menu(cb: CallbackQuery) -> None:
    from keyboards.menus import main_menu
    await cb.message.edit_text("Главное меню:", reply_markup=main_menu())
    await cb.answer()


@router.callback_query(F.data == "balance")
async def balance(cb: CallbackQuery) -> None:
    async with SessionLocal() as session:
        user = await economy.get_or_create_user(session, cb.from_user.id, cb.from_user.username)
    await cb.answer(f"💰 Баланс: {user.balance} фишек", show_alert=True)


@router.callback_query(F.data == "ref")
async def referral(cb: CallbackQuery) -> None:
    me = await cb.bot.get_me()
    link = f"https://t.me/{me.username}?start=ref_{cb.from_user.id}"
    await cb.message.edit_text(
        f"👥 <b>Реферальная программа</b>\n\n"
        f"Приглашай друзей. Когда приглашённый пополняет виртуальный баланс, "
        f"ты получаешь <b>{settings.referral_percent}%</b> от суммы его пополнения — фишками.\n\n"
        f"Твоя ссылка:\n<code>{link}</code>",
        reply_markup=(await _menu_kb()))
    await cb.answer()


async def _menu_kb():
    from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup
    return InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="⬅️ Меню", callback_data="menu")]])
