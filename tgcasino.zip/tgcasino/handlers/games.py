from aiogram import F, Router
from aiogram.types import CallbackQuery

from core import economy, games
from db.database import SessionLocal
from keyboards.menus import (bet_amounts, coin_choices, crash_cashouts,
                             dice_guesses, main_menu, rb_choices)

router = Router()

GAME_TITLES = {
    "dice": "🎲 Кубик — угадай число 1–6 (выплата ~x5.8)",
    "coin": "🪙 Монетка — орёл или решка (выплата ~x1.94)",
    "rb": "🔴 Красное/Чёрное (есть зелёный 0, выплата ~x1.99)",
    "slots": "🎰 Слоты — три в ряд = джекпот",
    "crash": "🚀 Crash — выбери авто-кэшаут",
}


@router.callback_query(F.data.startswith("game:"))
async def choose_bet(cb: CallbackQuery) -> None:
    game = cb.data.split(":")[1]
    await cb.message.edit_text(
        f"{GAME_TITLES[game]}\n\nВыбери размер ставки (фишки):",
        reply_markup=bet_amounts(game))
    await cb.answer()


@router.callback_query(F.data.startswith("bet:"))
async def choose_option(cb: CallbackQuery) -> None:
    _, game, amount = cb.data.split(":")
    amount = int(amount)
    if game == "dice":
        await cb.message.edit_text("Выбери число:", reply_markup=dice_guesses(amount))
    elif game == "coin":
        await cb.message.edit_text("Орёл или решка?", reply_markup=coin_choices(amount))
    elif game == "rb":
        await cb.message.edit_text("Красное или чёрное?", reply_markup=rb_choices(amount))
    elif game == "crash":
        await cb.message.edit_text("Выбери авто-кэшаут:", reply_markup=crash_cashouts(amount))
    elif game == "slots":
        await _play(cb, game, amount, None)
    await cb.answer()


@router.callback_query(F.data.startswith("play:"))
async def play_with_option(cb: CallbackQuery) -> None:
    _, game, amount, option = cb.data.split(":")
    await _play(cb, game, int(amount), option)
    await cb.answer()


async def _play(cb: CallbackQuery, game: str, amount: int, option: str | None) -> None:
    async with SessionLocal() as session:
        user = await economy.get_or_create_user(session, cb.from_user.id, cb.from_user.username)
        if user.balance < amount:
            await cb.answer("Недостаточно фишек!", show_alert=True)
            return

        ss, cs, nonce = user.server_seed, user.client_seed, user.nonce
        if game == "dice":
            result = games.dice_guess(amount, int(option), ss, cs, nonce)
        elif game == "coin":
            result = games.coin_flip(amount, option, ss, cs, nonce)
        elif game == "rb":
            result = games.red_black(amount, option, ss, cs, nonce)
        elif game == "slots":
            result = games.slots(amount, ss, cs, nonce)
        elif game == "crash":
            crash = games.crash_point(ss, cs, nonce)
            result = games.crash_settle(amount, float(option), crash)
        else:
            await cb.answer("Неизвестная игра", show_alert=True)
            return

        try:
            user = await economy.settle_bet(session, user, game, amount, result)
        except ValueError:
            await cb.answer("Недостаточно фишек!", show_alert=True)
            return

    status = "✅ Победа!" if result.win else "❌ Проигрыш"
    delta = f"+{result.payout}" if result.payout >= 0 else str(result.payout)
    await cb.message.edit_text(
        f"{status}\n"
        f"Игра: {game} | Результат: <code>{result.result}</code>\n"
        f"Изменение: <b>{delta}</b> фишек\n"
        f"Баланс: <b>{user.balance}</b> фишек",
        reply_markup=main_menu())
