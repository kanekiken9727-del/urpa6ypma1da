from aiogram import F, Router
from aiogram.types import CallbackQuery

from core import economy
from db.database import SessionLocal

router = Router()


@router.callback_query(F.data == "top")
async def top(cb: CallbackQuery) -> None:
    async with SessionLocal() as session:
        users = await economy.leaderboard(session, limit=10)
    lines = ["🏆 <b>Топ игроков</b>\n"]
    for i, u in enumerate(users, 1):
        name = f"@{u.username}" if u.username else f"id{u.id}"
        lines.append(f"{i}. {name} — {u.balance} фишек")
    from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup
    kb = InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="⬅️ Меню", callback_data="menu")]])
    await cb.message.edit_text("\n".join(lines), reply_markup=kb)
    await cb.answer()
