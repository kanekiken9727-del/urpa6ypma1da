from aiogram import F, Router
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import (CallbackQuery, InlineKeyboardButton,
                           InlineKeyboardMarkup, Message)

from core import economy, provably_fair as pf
from db.database import SessionLocal

router = Router()


class SeedStates(StatesGroup):
    waiting_client_seed = State()


def _back_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="⬅️ Меню", callback_data="menu")]])


@router.callback_query(F.data == "fair")
async def fairness(cb: CallbackQuery) -> None:
    async with SessionLocal() as session:
        user = await economy.get_or_create_user(session, cb.from_user.id, cb.from_user.username)
        h = pf.server_seed_hash(user.server_seed)
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="✏️ Сменить client seed", callback_data="seed:setclient")],
        [InlineKeyboardButton(text="🔄 Ротация server seed (раскрыть старый)", callback_data="seed:rotate")],
        [InlineKeyboardButton(text="⬅️ Меню", callback_data="menu")],
    ])
    await cb.message.edit_text(
        "🔎 <b>Provably Fair</b>\n\n"
        f"Хеш server seed (опубликован заранее):\n<code>{h}</code>\n"
        f"Твой client seed: <code>{user.client_seed}</code>\n"
        f"Текущий nonce: <code>{user.nonce}</code>\n\n"
        "Зная только хеш, вычислить server seed нельзя, поэтому заранее узнать исход "
        "и «играть только на победу» невозможно. После ротации старый seed раскрывается — "
        "и любой раунд можно перепроверить.",
        reply_markup=kb)
    await cb.answer()


@router.callback_query(F.data == "seed:setclient")
async def ask_client_seed(cb: CallbackQuery, state: FSMContext) -> None:
    await state.set_state(SeedStates.waiting_client_seed)
    await cb.message.edit_text(
        "Отправь свой client seed (до 32 символов). Он войдёт в расчёт каждого раунда.\n"
        "Смена client seed также ротирует server seed и раскрывает предыдущий.",
        reply_markup=_back_kb())
    await cb.answer()


@router.message(SeedStates.waiting_client_seed)
async def receive_client_seed(message: Message, state: FSMContext) -> None:
    await state.clear()
    async with SessionLocal() as session:
        user = await economy.get_or_create_user(session, message.from_user.id, message.from_user.username)
        user = await economy.set_client_seed(session, user, message.text or "")
        h = pf.server_seed_hash(user.server_seed)
    await message.answer(
        f"✅ Client seed установлен: <code>{user.client_seed}</code>\n"
        f"Новый хеш server seed: <code>{h}</code>\nnonce сброшен в 0.",
        reply_markup=_back_kb())


@router.callback_query(F.data == "seed:rotate")
async def rotate(cb: CallbackQuery) -> None:
    async with SessionLocal() as session:
        user = await economy.get_or_create_user(session, cb.from_user.id, cb.from_user.username)
        revealed = await economy.rotate_server_seed(session, user)
        new_hash = pf.server_seed_hash(user.server_seed)
    await cb.message.edit_text(
        "🔄 <b>Server seed ротирован.</b>\n\n"
        "Раскрытый предыдущий server seed (проверь, что его SHA-256 = ранее опубликованному хешу):\n"
        f"<code>{revealed.server_seed}</code>\n"
        f"Его хеш: <code>{revealed.server_seed_hash}</code>\n"
        f"client seed: <code>{revealed.client_seed}</code>, раундов: {revealed.max_nonce}\n\n"
        f"Новый хеш server seed: <code>{new_hash}</code>",
        reply_markup=_back_kb())
    await cb.answer()
