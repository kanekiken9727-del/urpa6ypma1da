from aiogram.types import (InlineKeyboardButton, InlineKeyboardMarkup,
                           WebAppInfo)

from config import settings


def main_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🎲 Кубик", callback_data="game:dice"),
         InlineKeyboardButton(text="🪙 Монетка", callback_data="game:coin")],
        [InlineKeyboardButton(text="🔴 Красное/Чёрное", callback_data="game:rb"),
         InlineKeyboardButton(text="🎰 Слоты", callback_data="game:slots")],
        [InlineKeyboardButton(text="🚀 Crash", callback_data="game:crash")],
        [InlineKeyboardButton(text="💰 Баланс", callback_data="balance"),
         InlineKeyboardButton(text="🏆 Топ", callback_data="top")],
        [InlineKeyboardButton(text="👥 Рефералка", callback_data="ref"),
         InlineKeyboardButton(text="🔎 Fairness", callback_data="fair")],
        [InlineKeyboardButton(text="🕹 Открыть Mini App",
                              web_app=WebAppInfo(url=settings.webapp_url))],
    ])


def bet_amounts(game: str) -> InlineKeyboardMarkup:
    rows = []
    amounts = [10, 50, 100, 500]
    rows.append([InlineKeyboardButton(text=f"{a}", callback_data=f"bet:{game}:{a}") for a in amounts])
    rows.append([InlineKeyboardButton(text="⬅️ Меню", callback_data="menu")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def dice_guesses(amount: int) -> InlineKeyboardMarkup:
    row = [InlineKeyboardButton(text=str(n), callback_data=f"play:dice:{amount}:{n}") for n in range(1, 7)]
    return InlineKeyboardMarkup(inline_keyboard=[row, [InlineKeyboardButton(text="⬅️ Меню", callback_data="menu")]])


def coin_choices(amount: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="Орёл", callback_data=f"play:coin:{amount}:heads"),
        InlineKeyboardButton(text="Решка", callback_data=f"play:coin:{amount}:tails"),
    ], [InlineKeyboardButton(text="⬅️ Меню", callback_data="menu")]])


def rb_choices(amount: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="🔴 Красное", callback_data=f"play:rb:{amount}:red"),
        InlineKeyboardButton(text="⚫ Чёрное", callback_data=f"play:rb:{amount}:black"),
    ], [InlineKeyboardButton(text="⬅️ Меню", callback_data="menu")]])


def crash_cashouts(amount: int) -> InlineKeyboardMarkup:
    row = [InlineKeyboardButton(text=f"{c}x", callback_data=f"play:crash:{amount}:{c}")
           for c in ("1.5", "2.0", "3.0", "5.0")]
    return InlineKeyboardMarkup(inline_keyboard=[row, [InlineKeyboardButton(text="⬅️ Меню", callback_data="menu")]])
