@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set LOGFILE=start-error.log

echo ==== TG Casino launcher %date% %time% ==== > "%LOGFILE%"
echo Project folder: %CD% >> "%LOGFILE%"

echo [1/5] Checking Python...
where python >> "%LOGFILE%" 2>&1
if errorlevel 1 goto :python_error
python --version >> "%LOGFILE%" 2>&1
if errorlevel 1 goto :python_error

if not exist ".venv\Scripts\python.exe" (
  echo [2/5] Creating virtual environment...
  python -m venv .venv >> "%LOGFILE%" 2>&1
  if errorlevel 1 goto :error
)

call ".venv\Scripts\activate.bat" >> "%LOGFILE%" 2>&1
if errorlevel 1 goto :error

echo [3/5] Installing/checking dependencies...
python -m pip install -r requirements.txt >> "%LOGFILE%" 2>&1
if errorlevel 1 goto :error

if not exist ".env" (
  echo [ERROR] File .env not found. Create it from .env.example.
  echo [ERROR] File .env not found. >> "%LOGFILE%"
  goto :error
)

findstr /B "BOT_TOKEN=" .env >> "%LOGFILE%" 2>&1
findstr /B "DATABASE_URL=" .env >> "%LOGFILE%" 2>&1

echo [4/5] Initializing PostgreSQL tables...
python -m db.init_db >> "%LOGFILE%" 2>&1
if errorlevel 1 goto :database_error

echo [5/5] Starting API and Telegram bot...
start "TG Casino API" cmd /k "cd /d "%CD%" && .venv\Scripts\python.exe api.py"
.venv\Scripts\python.exe bot.py >> "%LOGFILE%" 2>&1
if errorlevel 1 goto :error

goto :done

:python_error
echo [ERROR] Python is not installed or not available in PATH.
goto :error

:database_error
echo [ERROR] PostgreSQL is not running or DATABASE_URL is incorrect.
echo Check start-error.log for details.
goto :error

:error
echo.
echo ===== LAUNCH FAILED =====
echo The detailed log was saved to:
echo %CD%\%LOGFILE%
echo Do not send your .env file or BOT_TOKEN.
echo.
pause
exit /b 1

:done
echo Bot stopped. Log: %CD%\%LOGFILE%
pause
