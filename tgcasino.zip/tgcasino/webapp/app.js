// Minimal Mini App front-end.
// NOTE: For a real deployment, wire these buttons to your backend HTTP API,
// which must validate Telegram initData (HMAC) and run the SAME provably-fair
// game logic server-side. Never trust game results computed in the client.

const tg = window.Telegram?.WebApp;
tg?.ready();
tg?.expand();

const balanceEl = document.getElementById('balance');
const resultEl = document.getElementById('result');

// Demo state only (server is the source of truth in production).
let balance = 1000;
balanceEl.textContent = balance;

// Build dice buttons 1..6
const diceWrap = document.getElementById('dice-buttons');
for (let n = 1; n <= 6; n++) {
  const b = document.createElement('button');
  b.textContent = n;
  b.addEventListener('click', () => play('dice', { guess: n }));
  diceWrap.appendChild(b);
}

document.querySelectorAll('[data-choice]').forEach(btn => {
  btn.addEventListener('click', () => play('coin', { choice: btn.dataset.choice }));
});

async function play(game, params) {
  const bet = 50;
  if (balance < bet) { resultEl.textContent = 'Недостаточно фишек'; return; }
  // In production:
  //   const res = await fetch('/api/play', {method:'POST',
  //     headers:{'Content-Type':'application/json'},
  //     body: JSON.stringify({ initData: tg.initData, game, bet, ...params })});
  //   const data = await res.json(); balance = data.balance; ...
  resultEl.textContent = 'Отправка ставки на сервер... (demo)';
}
