const $ = (id) => document.getElementById(id);
$("check").addEventListener("click", async () => {
  const payload = {
    server_seed: $("ss").value.trim(),
    server_seed_hash: $("hash").value.trim(),
    client_seed: $("cs").value.trim(),
    nonce: parseInt($("nonce").value || "0", 10),
  };
  const res = await fetch("/api/verify", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  const data = await res.json();
  $("out").textContent = JSON.stringify(data, null, 2) +
    (data.hash_matches ? "\n\n✅ Хеш совпадает — сид подлинный." :
                         "\n\n❌ Хеш НЕ совпадает — данные не сходятся.");
});
